import requests

response = requests.post('http://127.0.0.1:5000/user', json={"name": 'user_2', 'password': '123gwesgtewt544'})
print(response.status_code)
print(response.text)

# response = requests.get('http://127.0.0.1:5000/user/8')
# print(response.status_code)
# print(response.text)


# response = requests.patch('http://127.0.0.1:5000/user/7', json={"name": "new_user_name"})
# print(response.status_code)
# print(response.text)
#
# response = requests.delete("http://127.0.0.1:5000/user/7")
# print(response.status_code)
# print(response.text)
#
#
# response = requests.get("http://127.0.0.1:5000/user/7")
# print(response.status_code)
# print(response.text)
